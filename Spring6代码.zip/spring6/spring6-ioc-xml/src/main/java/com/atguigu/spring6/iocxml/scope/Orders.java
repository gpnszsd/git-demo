package com.atguigu.spring6.iocxml.scope;

public class Orders {

}
