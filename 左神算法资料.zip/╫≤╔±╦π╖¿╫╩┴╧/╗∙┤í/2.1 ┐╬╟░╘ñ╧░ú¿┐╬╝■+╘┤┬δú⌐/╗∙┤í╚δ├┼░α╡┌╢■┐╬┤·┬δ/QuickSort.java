package class02;

import java.util.Arrays;

public class QuickSort {
    public  static int partition(int[] arr,int l,int h){
        int tem = arr[l];
        int low = l,high = h;
        while (low<high){
            while (arr[high]>=tem&&low<high){
                high--;
            }
            if(low<high){
                arr[low] = arr[high];
                low++;
            }

            while (arr[low]<=tem&&low<high){
                low++;
            }
            if(low<high){
                arr[high]=arr[low];
                high--;
            }


        }

        arr[low]= tem;
        return  low;

    }

    public  static  void proceess(int [] arr, int l,int h){
if(l==h){
    return;
}
//不写l<h就报错，其他排序算法就不用写？？？？？？？？？？？？？？？？？？？？
        if(l<h){
            int mid = partition(arr,l,h);
            proceess(arr,l,mid-1);
            proceess(arr,mid+1,h);
        }


    }

    public static void main(String[] args) {
        int[] arr ={1,1,1,7,7,3,5,2,6,6};
        proceess(arr,0,arr.length-1);
        System.out.println(Arrays.toString(arr));
    }
}
