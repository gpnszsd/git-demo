package com.atguigu.spring6.resource.dao;

public interface UserDao {

    public void add();
}
