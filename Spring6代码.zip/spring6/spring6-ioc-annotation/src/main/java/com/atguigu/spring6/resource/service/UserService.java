package com.atguigu.spring6.resource.service;

public interface UserService {

    public void add();
}
