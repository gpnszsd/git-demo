package com.atguigu.spring6.junit.junit5;

import org.springframework.stereotype.Component;

@Component
public class User {

    public void run() {
        System.out.println("user.....");
    }
}
