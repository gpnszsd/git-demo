package class07;

import java.util.ArrayList;
import java.util.Arrays;

public class Unity1 {
//    public static int rob (ArrayList<Integer> nums) {
//        if(nums==null||nums.size()==0)
//            return 0;
//
//        int l = nums.size();
//        if(l==1) return nums.get(0);
//        int[] dp = new int[l];
//        dp[0] =nums.get(0);
//        dp[1] = Math.max(nums.get(0),nums.get(1));
//        for (int i = 2; i < l; i++) {
//            dp[i] = Math.max(dp[i-2]+ nums.get(i),dp[i-1]);
//
//        }
//        return  dp[l-1];
//
//
//
//                Integer[] arr= nums.toArray(new  Integer[nums.size()]);
//        int n= arr.length;
//        int[] m = new int[n-1];
//        for (int i = 0; i <=n; i++) {
//            m[i]=arr[i-1];
//        }
//
//        int[][] p  = new int[n+1][2];
//        for (int i = 0; i <= n; i++) {
//            Arrays.fill(p[i],-1000000000);
//            p[0][0]= 0;
//
//        }
//        for (int i = 0; i <= n; i++) {
//            for (int j = 0; j < 2; j++) {
//                p[i][1] =Math.max(p[i][1],p[i-1][0]+m[i]);
//                p[i][0] =Math.max(p[i-1][0],p[i-1][1]);
//            }
//        }
//
//        return Math.max(p[n][0],p[n][1]);
//        // write code here
//    }

    public static void main(String[] args) {
        ArrayList<Integer> l = new ArrayList<>();
        l.add(1);
        l.add(2);
        l.add(3);
        l.add(4);
Integer[] att  = l.toArray(new Integer[l.size()]);
int a = att[0];
Integer bb = new Integer(11);
Integer b =bb;
        System.out.println(b);

        System.out.println(Arrays.toString(att));



    }
}
