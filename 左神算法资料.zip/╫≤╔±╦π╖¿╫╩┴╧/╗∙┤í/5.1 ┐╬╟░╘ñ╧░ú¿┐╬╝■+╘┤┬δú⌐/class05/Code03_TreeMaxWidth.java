package class05;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;

public class Code03_TreeMaxWidth {

	public static class Node {
		public int value;
		public Node left;
		public Node right;

		public Node(int data) {
			this.value = data;
		}
	}

	public static int getMaxWidth(Node head) {
		if (head == null) {
			return 0;
		}
		int maxWidth = 0;
		int curWidth = 0;
		int curLevel = 0;
		HashMap<Node, Integer> levelMap = new HashMap<>();
		levelMap.put(head, 1);
		LinkedList<Node> queue = new LinkedList<>();
		queue.add(head);
		Node Node = null;
		Node left = null;
		Node right = null;
		while (!queue.isEmpty()) {
			Node = queue.poll();
			left = Node.left;
			right = Node.right;
			if (left != null) {
				levelMap.put(left, levelMap.get(Node) + 1);
				queue.add(left);
			}
			if (right != null) {
				levelMap.put(right, levelMap.get(Node) + 1);
				queue.add(right);
			}
			if (levelMap.get(Node) > curLevel) {
				curWidth = 0;
				curLevel = levelMap.get(Node);
			} else {
				curWidth++;
			}
			maxWidth = Math.max(maxWidth, curWidth);
		}
		return maxWidth;


	}

//leetcode662.最大宽度题目
	public int widthOfBinaryTree(Node root) {

		Queue<Node> q = new LinkedList<>();
		int curLevel = 1;
		int curLevelNodes = 0;
		int a=0;
		int max = Integer.MIN_VALUE;

		q.add(root);
		HashMap<Node, Integer> h = new HashMap<>();
		ArrayList<Node> arr = new ArrayList<>();
		h.put(root, 1);
		while (!q.isEmpty()) {
			Node cur = q.poll();
			int curNodeLevel  = h.get(cur);
			if (curNodeLevel == curLevel) {
				curLevelNodes++;
				arr.add(cur);
			} else {
				int p1=0,p2=0;
				LinkedList<Integer> linkedList = new LinkedList<>();
				for (int i = 0; i <= arr.size() -1; i++) {
					if(arr.get(i).value != 110){
						linkedList.add(i);
					}
				}

//				for (int i = arr.size() -1; i >=0; i--) {
//					if(arr.get(i).value != 110){
//						p2= i;
//						break;
//					}
//				}
//				if(p1==0&&p2==0) a=0;
//				if(p2>=p1) a=p2-p1+1;
//				else a=0;
if(linkedList.size()==1) a=1;
if(linkedList.size() ==0) a=0;
a= linkedList.getFirst()-linkedList.getFirst()+1;
				max = Math.max(max, a);
				curLevel++;
				curLevelNodes = 1;
				arr.add(cur);
			}
			if(cur.left==null){
				cur.left = new Node(110);
			}
				h.put (cur.left,curLevel+1);
				q.add(cur.left);

			if(cur.right==null){
				cur.right = new Node(110);
			}
				h.put (cur.right,curLevel+1);
				q.add(cur.right);
		}
		return max;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Node head =new Node(1);


	}

}
