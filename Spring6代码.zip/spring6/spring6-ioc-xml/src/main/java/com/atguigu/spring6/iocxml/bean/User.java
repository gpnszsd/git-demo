package com.atguigu.spring6.iocxml.bean;

public class User {

    private String name;
    private Integer age;

    public void run() {
        System.out.println("run......");
    }
}
