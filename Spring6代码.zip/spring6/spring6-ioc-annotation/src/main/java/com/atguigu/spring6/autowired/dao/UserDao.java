package com.atguigu.spring6.autowired.dao;

public interface UserDao {

    public void add();
}
