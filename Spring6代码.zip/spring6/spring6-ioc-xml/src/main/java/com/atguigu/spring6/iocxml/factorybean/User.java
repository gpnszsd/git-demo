package com.atguigu.spring6.iocxml.factorybean;

public class User {
}
