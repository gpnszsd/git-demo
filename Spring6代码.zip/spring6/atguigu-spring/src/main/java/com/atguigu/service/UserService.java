package com.atguigu.service;

public interface UserService {

    void add();
}
