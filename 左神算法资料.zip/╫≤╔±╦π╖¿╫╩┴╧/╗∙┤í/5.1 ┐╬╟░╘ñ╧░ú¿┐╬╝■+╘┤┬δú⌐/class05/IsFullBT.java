package class05;

public class IsFullBT {

    public static class    Node{
        public  int value;
        public Node left;
        public  Node right;
        public Node(int value) {
            this.value = value;
        }
    }

//错误；
    public  static Boolean  isFull(Node head){
        if(head == null) {
                return true;
        }
        return  isFull(head.left)&&isFull(head.right);
    }

    public static void main(String[] args) {
        Node head= new Node(1);
        head.left =new Node(2);
        head.right = new Node(3);
        head.left.left=new Node(2);
        System.out.println(isFull(head));

        System.out.println(3>>2);
    }
}
