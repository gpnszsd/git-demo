package com.atguigu.spring6.iocxml.auto.dao;

public interface UserDao {

    public void addUserDao();
}
