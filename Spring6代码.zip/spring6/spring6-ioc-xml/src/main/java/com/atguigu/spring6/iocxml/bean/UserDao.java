package com.atguigu.spring6.iocxml.bean;

public interface UserDao {

    public void run();
}
