package class02;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;

public class HeapSort {
    public  static void swap (int[] arr,int i,int j){
        int tem =arr[i];
        arr[i]= arr[j];
        arr[j] =arr[i];

    }

    public  static  void heapfy(int [] arr,int s, int size){

        for (int j = 2*s+1; j <= size-1; j=j*2+1) {
            if(j<size-1 && arr[j]>arr[j+1]){
                j++;
            }
            if(arr[s]<=arr[j]){
               break;
            }
            swap(arr,s,j);
            s= j;
        }
    }

    public static void heapify(int[] arr, int index, int size) {
        int left = index * 2 + 1;
        while (left < size) {
            int largest = left + 1 < size && arr[left + 1] > arr[left] ? left + 1 : left;
            largest = arr[largest] > arr[index] ? largest : index;
            if (largest == index) {
                break;
            }
            swap(arr, largest, index);
            index = largest;
            left = index * 2 + 1;
        }
    }

    public static void main(String[] args) {
//        int [] arr = {97,38,27,50,76,65,49};
//        heapify(arr,0, arr.length);
//        System.out.println(Arrays.toString(arr));

        PriorityQueue<Integer>   pq =    new PriorityQueue<>();
        pq.add(13);
        pq.add(38);
        pq.add(27);
        pq.add(50);
        pq.add(76);
        pq.add(65);
        pq.add(49);
        pq.add(97);
        System.out.println(pq.poll());
        System.out.println(pq.poll());
        System.out.println(pq.poll());
        System.out.println(pq.poll());
        System.out.println(pq.poll());
        System.out.println(pq.poll());
        System.out.println(pq.poll());
        System.out.println(pq.poll());




//        for (int i = 0; i < pq.size(); i++) {
//            System.out.println(pq.poll());
//        }

//自定义比较器
      Comparator<Integer> c = new Comparator<Integer>() {
           @Override
           public int compare(Integer o1, Integer o2) {
               return 0;
           }
       };

        HashMap<Integer,Integer> hm = new HashMap<>();
        hm.put (1,1);
        System.out.println(hm);

    }
}
