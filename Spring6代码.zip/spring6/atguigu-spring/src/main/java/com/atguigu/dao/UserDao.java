package com.atguigu.dao;

public interface UserDao {

    void add();
}
