package class01;

public class Code06_BSAwesome {
//一个数组，无序，元素各不相同，寻找一个局部最小值（必能找出一个），起始点和终止点的局部最小只考虑一边      if(arr[0]<arr[1]) System.out.println (0);
//		                                                                 if(arr[h]<arr[h-1]) System.out.println(h);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {2,1, 4, 6, 1, 2};
		int l = 0, h = arr.length - 1;
		if(arr[0]<arr[1]) System.out.println (0);
		if(arr[h]<arr[h-1]) System.out.println(h);
		if (arr[l] > arr[l + 1] && arr[h] > arr[h - 1]) {
			while (l <= h) {
				int m = (l + h) / 2;
				if (arr[m] < arr[m - 1] && arr[m] < arr[m + 1]) {
					System.out.println(m);
					break;
				} else if (arr[m] > arr[m - 1]) {
					h = m;
				} else if (arr[m] > arr[m + 1]) {
					l = m;
				} else if (arr[m] < arr[m - 1]) {
					l = m - 1;
				} else if (arr[m] < arr[m + 1]) {
					h = m + 1;
				}


			}
		}

	}
}