package com.atguigu.spring6.iocxml.auto.service;

public interface UserService {

    public void addUserService();
}
