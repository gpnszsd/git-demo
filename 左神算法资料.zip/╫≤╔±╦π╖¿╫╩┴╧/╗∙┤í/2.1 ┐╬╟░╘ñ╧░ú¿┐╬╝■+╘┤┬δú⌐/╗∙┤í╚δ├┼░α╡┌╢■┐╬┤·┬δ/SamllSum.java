package class02;

import java.util.Arrays;

public class SamllSum {
//    static  int res =0;

    public  static int  merge(int [] arr,int l,int m,int h ){
        int res =0;
        int[] help  = new  int[arr.length];
        int i = l, j =m+1 , k = l;
        while (i<=m&&j<=h){
            if(arr[i]< arr[j]) {res+=arr[i]*(h-j+1); help[k++] = arr[i++];}
            else help[k++] = arr[j++];
        }
        if(j<=h){
            while (j<=h) help[k++] = arr[j++];
        }if(i<=m) {
            while (i<=m)
                help[k++] = arr[i++];
        }
        for(int p=l;p<=h;p++){
            arr[p] = help[p];
        }

        System.out.println(Arrays.toString(arr));
        return  res;
    }

    public static int mergeSort(int[] arr, int l, int r) {
        if (l == r) {
            return 0;
        }
        int mid = l + ((r - l) >> 1);
        return mergeSort(arr, l, mid)
                + mergeSort(arr, mid + 1, r)
                + merge(arr, l, mid, r);
    }
    public static void main(String[] args) {
int[] arr ={3,1,4,5,2};
        System.out.println(mergeSort(arr,0,arr.length-1));

    }
}
