package class02;

import java.util.Arrays;

public class MergeSort {

    public  static  void  mergeSort(int [] arr,int l,int h ){
        if(l==h){
            return;
        }
        int mid = (l+h)/2;
        mergeSort( arr,l,mid);
        mergeSort( arr,mid+1,h);
        merge(arr,l,mid,h);

    }



//自己写的merge
    public  static void  merge(int [] arr,int l,int m,int h ){
        int[] help  = new  int[arr.length];
        int i = l, j =m+1 , k = l;
        while (i<=m&&j<=h){
            if(arr[i]<= arr[j]) help[k++] = arr[i++];
            else help[k++] = arr[j++];
        }
        if(j<=h){
            while (j<=h) help[k++] = arr[j++];
        }if(i<=m) {
            while (i<=m)
            help[k++] = arr[i++];
        }
        for(int p=l;p<=h;p++){
            arr[p] = help[p];
        }

        System.out.println(Arrays.toString(arr));
    }


    public static void main(String[] args) {

//        merge(new int[] {1,3,5,2,4,6,11},0,2,6);
        int[] arr ={1,3,5,2,4,6,11};
        mergeSort(arr,0,arr.length-1);


    }
}
