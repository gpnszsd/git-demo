package com.atguigu.spring6.di;

public class User {
}
