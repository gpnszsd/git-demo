package com.atguigu.spring6.bean;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

//@Component(value = "user") //<bean id="user" class="...">
//@Repository
//@Service
@Controller
public class User {
}
