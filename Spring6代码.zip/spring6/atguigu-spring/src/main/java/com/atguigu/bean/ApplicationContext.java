package com.atguigu.bean;

public interface ApplicationContext {

    Object getBean(Class clazz);
}
