package com.atguigu.spring6.autowired.service;

public interface UserService {

    public void add();
}
